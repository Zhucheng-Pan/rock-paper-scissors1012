var express = require('express');
var bodyParser = require('body-parser');

var app = express();
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(__dirname + '/public'));

app.listen(3000, function() {
  console.log('Server is running');
});

var usernames = [];
var passwords = [];

app.get("/login", function(req,res){
  res.sendFile(__dirname + "/public/login.html");
})

app.post("/login", function(req,res){
  var name = req.body.uname;
  var pass = req.body.psw;
  console.log(name);
  console.log(pass);
  for(var i = 0; i < usernames.length; i ++){
    if(name === usernames[i]){
      if(pass === passwords[i]){
        res.redirect('/rps');
      }
      else{
        res.send("wrong password");
      }
    }
  }
  res.send("no such user");
})

app.post("/login/new", function(req,res){
  var name = req.body.uname;
  var pass = req.body.psw;
  console.log(name);
  console.log(pass);
  usernames.push(name);
  passwords.push(pass);
  res.redirect('/rps');
})

app.get("/rps",function(req,res){
  res.sendFile(__dirname + "/public/rps.html");
})
