var choose = -1;
var p1score = 0;
var p2score = 0;
var p1name = "Player 1";
var p2name = "Player 2";
var cscore = 0;
var count = 0;
var replay = false;
function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}
const changename = function(e){
  p1name = document.getElementById("name1").value;
  document.getElementById("n1").innerText = p1name;
  p2name = document.getElementById("name2").value;
  document.getElementById("n2").innerText = p2name;
}
document.getElementById("name1").addEventListener("input", changename);
document.getElementById("name2").addEventListener("input", changename);
function clicked(id){
  var mode = document.getElementById("mode").checked;
  var winner = 0;
  if (mode === true){
    if(choose == -1){
      choose = id;
    }
    else{
      if((id == 0 && choose == 1) || (id == 1 && choose == 2) || (id == 2 && choose == 0)){
        alert( p1name+" Win");
        winner = 1;
      }
      else if(id === choose){
        alert("Tie")
        winner = 0;
      }
      else{
        alert(p2name+" Win");
        winner = 2;
      }
      if(winner == 1){
        p1score++;
      }
      if (winner === 2){
        p2score++;
      }
      choose = -1;
      count++;
    }
  }
  else{
    choose = getRandomInt(3);
    if((id == 0 && choose == 1) || (id == 1 && choose == 2) || (id == 2 && choose == 0)){
      alert("Win");
      winner = 1;
    }
    else if(id === choose){
      alert("Tie");
      winner = 0;
    }
    else{
      winner = 3;
      alert("Lose");
    }
    var changed = false;
    if(replay === false){
      if(confirm("replay?")){
        replay = true;
        changed = true;
      }
    }
    if(changed == false){
      if(winner == 1){
        p1score++;
      }
      if (winner === 3){
        cscore++;
      }
    }
    choose = -1;
    if(changed === false){
      count++;
    }
  }
  document.getElementById("p1").innerText=p1score;
  document.getElementById("p2").innerText=p2score;
  document.getElementById("c").innerText=cscore;
  if(count == 3){
    if(mode === true){
      alert(p1name + " score: " + p1score + " " + p2name + " score: " + p2score);
      if(p1score > p2score){
        alert(p1name + "Win!");
      }
      else if (p1score < p2score){
        alert(p2name + "Win!");
      }
      else{
        alert("Tie")
      }
    }
    else{
        alert(p1name + " score: " + p1score + " computer score: " + cscore);
        if(p1score > cscore){
          alert(p1name + "Win!");
        }
        else if (p1score < cscore){
          alert("computer Win!");
        }
        else{
          alert("Tie")
        }
    }
    count = 0;
    replay = false;
    p1score = 0;
    p2score = 0;
    cscore = 0;
  }
}